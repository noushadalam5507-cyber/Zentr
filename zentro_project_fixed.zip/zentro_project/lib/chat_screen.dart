import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'social_service.dart';
import 'video_call_screen.dart';
import 'chat_wallpaper_service.dart';

class ChatScreen extends StatefulWidget {
  final String otherUid;
  final String otherDisplayName;

  const ChatScreen({
    Key? key,
    required this.otherUid,
    required this.otherDisplayName,
  }) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final SocialService _social = SocialService();
  final TextEditingController _controller = TextEditingController();
  final String _myUid = FirebaseAuth.instance.currentUser!.uid;

  late final String _chatId = _social.chatIdFor(widget.otherUid);
  ChatWallpaper _wallpaper = kPresetWallpapers.first;

  @override
  void initState() {
    super.initState();
    ChatWallpaperService.get(_chatId).then((w) {
      if (mounted) setState(() => _wallpaper = w);
    });
  }

  Future<void> _openWallpaperPicker() async {
    final picked = await showModalBottomSheet<ChatWallpaper>(
      context: context,
      backgroundColor: const Color(0xFF120A1F),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Chat wallpaper',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final w in kPresetWallpapers)
                    GestureDetector(
                      onTap: () => Navigator.pop(context, w),
                      child: Column(
                        children: [
                          Container(
                            width: 56,
                            height: 56,
                            decoration: ChatWallpaperService.decorationFor(w)
                                .copyWith(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: w.id == _wallpaper.id
                                    ? const Color(0xFFFF1493)
                                    : Colors.white24,
                                width: 2,
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(w.label,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 11)),
                        ],
                      ),
                    ),
                  GestureDetector(
                    onTap: () async {
                      final picker = ImagePicker();
                      final file = await picker.pickImage(
                        source: ImageSource.gallery,
                        maxWidth: 1600,
                        imageQuality: 85,
                      );
                      if (file != null && context.mounted) {
                        Navigator.pop(context, ChatWallpaper.custom(file.path));
                      }
                    },
                    child: Column(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white24),
                          ),
                          child: const Icon(Icons.add_photo_alternate_outlined,
                              color: Colors.white70),
                        ),
                        const SizedBox(height: 4),
                        const Text('From gallery',
                            style:
                                TextStyle(color: Colors.white70, fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (picked != null) {
      await ChatWallpaperService.set(_chatId, picked);
      if (mounted) setState(() => _wallpaper = picked);
    }
  }

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _social.sendMessage(widget.otherUid, text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.otherDisplayName),
        actions: [
          IconButton(
            icon: const Icon(Icons.wallpaper),
            tooltip: 'Chat wallpaper',
            onPressed: _openWallpaperPicker,
          ),
          IconButton(
            icon: const Icon(Icons.call),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => VideoCallScreen(
                  channelName: _social.chatIdFor(widget.otherUid),
                  audioOnly: true,
                ),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.videocam),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => VideoCallScreen(
                  channelName: _social.chatIdFor(widget.otherUid),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: ChatWallpaperService.decorationFor(_wallpaper),
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder(
                stream: _social.messagesStream(widget.otherUid),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final docs = snapshot.data!.docs;
                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      final data = docs[index].data();
                      final isMe = data['senderId'] == _myUid;
                      return Align(
                        alignment: isMe
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isMe
                                ? const Color(0xFFFF1493)
                                : Colors.black45,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Text(
                            data['text'] ?? '',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      style: const TextStyle(color: Colors.white),
                      decoration:
                          const InputDecoration(hintText: "Message..."),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Color(0xFFFF1493)),
                    onPressed: _send,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
