import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'auth_service.dart';
import 'ai_help_assistant_screen.dart';
import 'privacy_service.dart';
import 'blocked_users_screen.dart';
import 'premium_screen.dart';
import 'coin_store_screen.dart';
import 'app_settings_service.dart';

/// A generic "Settings & Activity" screen. Every entry here links to a real
/// screen/action — nothing here fabricates data. If you build the
/// Device-permissions screen, wire real permission_handler logic behind it
/// the same way _handleSignOut() below wires a real sign-out.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final PrivacyService _privacy = PrivacyService();
  final String _myUid = FirebaseAuth.instance.currentUser!.uid;
  bool _voiceNavEnabled = false;

  @override
  void initState() {
    super.initState();
    AppSettingsService.isVoiceNavEnabled().then((value) {
      if (mounted) setState(() => _voiceNavEnabled = value);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Settings and Activity")),
      body: ListView(
        children: [
          _sectionHeader("How you use the app"),
          _tile(context, Icons.access_time, "Your Activity", () {}),
          _tile(context, Icons.archive, "Archive", () {}),

          _sectionHeader("Who can see your content"),
          StreamBuilder<bool>(
            stream: _privacy.isPrivateStream(_myUid),
            builder: (context, snapshot) {
              final isPrivate = snapshot.data ?? false;
              return SwitchListTile(
                secondary: const Icon(Icons.lock, color: Colors.white70),
                title: const Text("Private Account",
                    style: TextStyle(color: Colors.white)),
                subtitle: Text(
                  isPrivate
                      ? "Only your approved followers can see your content"
                      : "Anyone can see your content",
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
                value: isPrivate,
                onChanged: (value) => _privacy.setPrivate(value),
              );
            },
          ),
          _tile(context, Icons.block, "Blocked", () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const BlockedUsersScreen()),
            );
          }),
          _tile(context, Icons.notifications, "Close Friends", () {}),

          _sectionHeader("Your app and media"),
          SwitchListTile(
            secondary: const Icon(Icons.mic, color: Colors.white70),
            title: const Text("Voice-Controlled Reel Navigation",
                style: TextStyle(color: Colors.white)),
            subtitle: const Text(
              "Say \"next\"/\"down\" or \"back\"/\"up\" while watching Reels. "
              "Manual swipes keep working normally either way.",
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
            value: _voiceNavEnabled,
            onChanged: (value) async {
              await AppSettingsService.setVoiceNavEnabled(value);
              setState(() => _voiceNavEnabled = value);
            },
          ),
          _tile(context, Icons.perm_device_information, "Device Permissions",
              () {}),
          _tile(context, Icons.language, "Language", () {}),
          _tile(context, Icons.data_usage, "Data Usage", () {}),

          _sectionHeader("Monetization"),
          _tile(context, Icons.verified, "Premium Subscription (Blue Badge)",
              () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PremiumScreen()));
          }),
          _tile(context, Icons.monetization_on, "Coin Store", () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CoinStoreScreen()));
          }),

          _sectionHeader("Support"),
          _tile(context, Icons.smart_toy, "Cloud AI Chat", () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiHelpAssistantScreen()),
            );
          }),
          _tile(context, Icons.help_outline, "Help", () {}),
          _tile(context, Icons.info_outline, "About", () {}),

          _sectionHeader("Login"),
          _tile(context, Icons.logout, "Log Out", () async {
            await AuthService().signOut();
            if (context.mounted) {
              Navigator.of(context).popUntil((route) => route.isFirst);
            }
          }, color: Colors.redAccent),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Text(
          title,
          style: const TextStyle(
            color: Colors.white54,
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
      );

  Widget _tile(BuildContext context, IconData icon, String label,
      VoidCallback onTap, {Color? color}) {
    return ListTile(
      leading: Icon(icon, color: color ?? Colors.white70),
      title: Text(label, style: TextStyle(color: color ?? Colors.white)),
      trailing: const Icon(Icons.chevron_right, color: Colors.white30),
      onTap: onTap,
    );
  }
}
