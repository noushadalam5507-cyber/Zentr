import 'package:flutter/material.dart';
import 'privacy_service.dart';

class BlockedUsersScreen extends StatelessWidget {
  const BlockedUsersScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final privacy = PrivacyService();
    return Scaffold(
      appBar: AppBar(title: const Text("Blocked Users")),
      body: StreamBuilder(
        stream: privacy.blockedUsersStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                "You haven't blocked anyone.",
                style: TextStyle(color: Colors.white54),
              ),
            );
          }
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final blockedUid = docs[index].id;
              return ListTile(
                leading: const Icon(Icons.person, color: Colors.white70),
                title: Text(blockedUid,
                    style: const TextStyle(color: Colors.white)),
                trailing: TextButton(
                  onPressed: () => privacy.unblockUser(blockedUid),
                  child: const Text("Unblock"),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
