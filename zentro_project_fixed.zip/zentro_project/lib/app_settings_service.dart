import 'package:shared_preferences/shared_preferences.dart';

/// Small persisted app-settings store (grows here as more toggles are added).
class AppSettingsService {
  static const _voiceNavKey = 'voice_nav_enabled';

  static Future<bool> isVoiceNavEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_voiceNavKey) ?? false;
  }

  static Future<void> setVoiceNavEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_voiceNavKey, value);
  }
}
