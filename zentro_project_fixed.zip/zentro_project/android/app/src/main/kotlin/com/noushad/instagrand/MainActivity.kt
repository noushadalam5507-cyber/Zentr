package com.noushad.instagrand
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity() {
}
