# Instagrand — Apni Credentials Kahan Paste Karein

**Status of your 3 IDs — sab set ho chuke hain:**
- ✅ Firebase — `google-services.json` `android/app/google-services.json` par hai, applicationId `com.noushad.instagrand` sab jagah match hai.
- ✅ AdMob App ID — `AndroidManifest.xml` mein daali hui.
- ✅ AdMob Banner Unit ID — `lib/main.dart` mein daali hui.
- ✅ Agora App ID — `lib/agora_config.dart` line 10 par daali hui: `868473cb9fb846718fc575f433699315`

**Kuch bhi manually edit karne ki zaroorat nahi hai** — bas neeche di FlutLab build steps follow karo.

**Abhi bhi khali (optional):**
- Gemini API key — agar AI chat panel chalana hai to `lib/gemini_config.dart` line 9 mein daalo (aistudio.google.com/apikey se). Bina key ke chat panel ek friendly "not set up yet" message dikhayega, crash nahi karega.
- Agora "App Certificate" ON hai to `tempToken` bhi `agora_config.dart` mein daalni hogi — abhi certificate OFF maan ke chala hai.
- **Rewarded Ad Unit ID** — `lib/rewarded_ad_service.dart` mein abhi Google ka TEST rewarded ID laga hai. Aapki banner ID (`.../2583529714`) ek BANNER unit hai, rewarded ke liye reuse nahi ho sakti — AdMob console mein apne app (`ca-app-pub-9658260608635009~...`) ke andar ek naya **Rewarded** ad unit banao aur woh ID `rewarded_ad_service.dart` mein daalo.
- **Media generation model** — `generateMedia()` (`gemini_chat_service.dart`) abhi ek stub hai; jo bhi image/video generation API use karna chahte ho (Gemini image model ya koi aur), uska real call yahan daalna hoga.

## Naye monetization features (is turn mein add hue)

**1. Interstitial Ads** (`interstitial_ad_service.dart`) — Agora call khatam hone par aur "popular" profile (1000+ real followers) open hone par dikhta hai. Abhi TEST ad unit ID hai — AdMob console mein apne app ke andar naya **Interstitial** unit banao (banner/rewarded se alag) aur `interstitial_ad_service.dart` mein daal do. Har ad ke beech kam se kam 2-minute ka gap rakha hai taaki experience kharab na ho.

**2. Premium Subscription + Blue Badge** (`premium_screen.dart`, `subscription_service.dart`) — **Zaroori:** isPremium status client se kabhi set nahi hota. `backend/functions/index.js` ka Cloud Function hi, real Razorpay payment verify karne ke baad, Firestore mein likhta hai. Bina yeh deploy kiye, "Subscribe" button ek friendly "not configured" message dega, koi fake premium nahi milega. Steps `backend/functions/index.js` ke comments mein hain.

**3. Coin/Gifting System** (`coin_wallet_service.dart`, `coin_store_screen.dart`, `gifting_widget.dart`) — Coin **kharidna** (real money se) bhi Cloud Function se hi hota hai, same security pattern. Coin **gift bhejna** (already-owned coins ek user se doosre ko transfer) client-side Firestore transaction se hota hai — yeh safe hai kyunki isse naye coins nahi banate, sirf jo already hain unhe move karte hain. Call screen mein gift button tabhi dikhega jab `VideoCallScreen(hostUidForGifting: ...)` diya jaye.

### Backend deploy karna zaroori hai (payment features ke liye)
`backend/functions/index.js` aur `backend/firestore.rules` Flutter project ka hissa nahi hain — inhe Firebase CLI se alag deploy karna hoga:
```
firebase deploy --only functions
firebase deploy --only firestore:rules
```
`razorpay_config.dart` mein apna Razorpay Key ID aur deployed Cloud Function ka URL daalo — Key **Secret** kahin bhi Flutter code mein mat daalna, sirf Firebase Functions config/secret mein.

### FlutLab.io ke liye zaroori warning
`razorpay_flutter` ek native plugin hai (Android/iOS native SDK use karta hai). FlutLab jaise lightweight online builders aksar aise native plugins properly support nahi karte — build fail ho sakta hai ya checkout screen na khule. Payment features add karne ke baad, production build ke liye **Android Studio** ya local `flutter build apk` command line use karna recommend karta hoon; FlutLab sirf simple/webview-type apps ke liye reliable hai.


## Zaroori: Google Sign-In SHA-1 fingerprint (yeh ek cheez FlutLab se nahi ho sakti)
Yeh IDs se alag hai — is app ke liye zaroori hai, warna Google Sign-In fail hoga. Apne computer par terminal mein:
```
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```
Jo SHA-1 fingerprint milega, usse Firebase Console -> Project Settings -> Your Android app (`com.noushad.instagrand`) -> "Add fingerprint" mein paste karo. FlutLab apna khud ka signing certificate use karta hai, to FlutLab se build karne ke baad wahan ka SHA-1 bhi Firebase mein add karna padega — FlutLab ki build/export settings mein certificate SHA-1 dikhega.

## Optional cleanup
- `lib/gemini_config.dart` — chat panel ke liye Gemini API key.
- `lib/agora_config.dart` — agar Agora console mein "App Certificate" ON hai to `tempToken` bhi daalni hogi.

## FlutLab.io par build karne ke steps
1. `zentro_project.zip` (yeh poora folder) FlutLab.io par "Upload ZIP" se upload karo.
2. Toolbar mein "Build" -> "Android (.apk)" click karo.
3. Build complete hone ke baad, FlutLab ka signing certificate SHA-1 copy karke Firebase mein add karo (upar wala step) — warna sirf Google Sign-In fail hoga, baaki app chalega.


## Is turn mein add hui cheezein (Camera + Filters + Audio Mix + Voice Nav + Founder Badge)

**4. Real native Camera screen** (`camera_screen.dart`, `camera_filters.dart`) — `camera` package use karta hai, jo asli hardware camera open karta hai (dummy/mock nahi). Permission flow specifically aise likha hai ki black screen kabhi na aaye: pehle "requesting permission" loader dikhta hai, permission grant hone ke baad hi `CameraController.initialize()` await hota hai, aur tabhi live preview mount hoti hai. Permission deny hone par ek real "Open Settings" screen dikhti hai, blank screen nahi.

Filters (Normal/Soft Glow/Warm/Cool/Vivid/Mono) live camera feed par real-time colour-grade overlays hain — ye genuinely camera feed par chalte hain. **Honest limitation:** ye Snapchat/Instagram jaisi face-tracking AR filters (beauty smoothing, masks) nahi hain — uske liye Google ML Kit Face Detection ya ek paid SDK (Banuba/DeepAR) alag se integrate karna padega, jo iss scope se bahar hai. `CameraFilter` interface aisa likha hai ki baad mein real face-AR SDK usi jagah plug ho sake.

**5. Audio mixing** (`audio_mix_service.dart`) — `file_picker` se user apne phone se real `.mp3` chunta hai, `ffmpeg_kit_flutter_minimal` real FFmpeg encode chalakar usse recorded video mein mix karta hai (placeholder nahi). Agar FFmpeg native binary FlutLab build mein fail ho jaye, function chup-chaap original video hi return kar deta hai — user ko "mix failed" pata chal jayega, fake success nahi dikhega.

**6. Voice-controlled navigation** (`voice_control_service.dart`, Settings screen ka naya toggle) — `speech_to_text` (real on-device Android/iOS speech recognizer) "up/back/previous" aur "down/next/skip" sunta hai. Manual swipe iske bilkul independent hai (feed ke apne GestureDetector/PageView se), isliye voice ON karne se fast manual swipe kabhi slow/block nahi hota.

**7. Founder/Admin badge** (`profile_screen.dart`) — `noushadalam5507@gmail.com` se sign-in karne par profile par ek gold verified badge dikhta hai, kisi bhi viewer ko. Follower count **hamesha real Firestore count hi rehta hai** — koi fake 12M ya koi bhi hardcoded starting number nahi. Maine pichle session mein bhi yehi baat bataayi thi ki fake follower count doosre real users ko genuinely mislead karega, isliye woh part implement nahi kiya.

### ⚠️ FlutLab.io par naye native plugins ka risk
`camera`, `ffmpeg_kit_flutter_minimal`, aur `speech_to_text` — teeno native Android/iOS code use karte hain (`razorpay_flutter` jaisa hi). FlutLab jaisa lightweight browser-based builder in teeno ko reliably build nahi kar sakta — specifically `ffmpeg_kit_flutter_minimal` bahut bada native binary hai (~40-80MB) jo FlutLab par build timeout/storage limit se fail hone ka strong chance hai.

**Agar FlutLab build fail ho:**
1. Sabse pehle sirf `camera` + `speech_to_text` ke saath build try karo (`pubspec.yaml` se ffmpeg line hataakar) — camera preview aur voice nav kaam karenge, sirf audio-mixing disable ho jayegi.
2. Agar wo bhi fail ho, to production APK ke liye Android Studio ya local `flutter build apk` (command line) use karna hoga — ye sabse reliable tareeka hai jab native plugins involved hon.
3. FlutLab sirf simple/webview-type apps ke liye consistently reliable hai; jaise-jaise native plugins (Agora, Razorpay, Camera, FFmpeg) badhte gaye hain, waise-waise ek local Flutter build environment zyada zaroori hota ja raha hai.

## Is turn mein add hui cheez (Custom Chat Wallpaper)

**8. Custom chat wallpaper** (`chat_wallpaper_service.dart`, chat screen ka naya 🖼️ icon) — Har chat ke liye alag background: 4 preset gradients ya `image_picker` se apni gallery se ek real photo chuno. Per-chat choice device par `SharedPreferences` mein save hoti hai. Agar picked photo file kabhi delete ho jaye, app crash nahi karta — chup-chaap default par wapas aa jaata hai.

## ⚠️ Ek zaroori sach — "sab kuch bind kar diya" ka matlab

Maine pichle turn ke saare features (camera, filters, audio-mix, voice-nav, admin badge) is same zip mein already combine kar rakhe hain — wo sab already ek hi codebase mein hain, alag se "bind" karne ki zaroorat nahi thi. Lekin do cheezein clear karna zaroori hai taaki FlutLab par surprise na ho:

- **"Heavy AR filters"** abhi bhi genuinely Snapchat/Instagram-level face-tracking AR nahi hain — woh 6 real-time colour filters hain jo live camera feed par kaam karte hain, face-mesh/beauty-smoothing nahi. Asli face AR ke liye ek dedicated SDK (ML Kit ya paid Banuba/DeepAR) chahiye — ye maine pehle bhi bataya tha aur ab bhi wahi sach hai; main "AR filters" hone ka jhoothा daava nahi karunga.
- **50MB+ build size** — ye khud koi feature nahi jo maine "add" kiya ho, ye sirf `ffmpeg_kit_flutter_minimal` (audio-video mixing ke liye) ka real native binary size hai. Ye zip me already hai, lekin FlutLab jaise lightweight browser builder par isi size/native-plugin combination ki wajah se build **fail ho sakta hai** — ye guarantee nahi kar sakta ki FlutLab isse handle kar lega, chahe main kitna bhi "bind" kar doon. Agar fail ho to neeche wala fallback (ffmpeg line hataakar rebuild, ya local Android Studio) hi realistic solution hai.

## Is turn mein add hui cheez (Missing Android build scaffolding)

Pichle zip mein `android/` folder incomplete tha — sirf `build.gradle` + `AndroidManifest.xml` + `MainActivity.kt` the. Ye files missing thi jo **kisi bhi build ke liye zaroori hain** (FlutLab ho ya local), isliye maine add ki:
- `android/settings.gradle` — `:app` module include karta hai (iske bina Gradle project hi resolve nahi hota)
- `android/gradle.properties` — AndroidX/Jetifier flags on, aur JVM heap thoda bada (`-Xmx2G`) kyunki `ffmpeg_kit_flutter_minimal` jaisa bhaari native plugin build ke dauraan zyada memory maangta hai
- `res/values/styles.xml` (+ `values-night`) — `LaunchTheme`/`NormalTheme`, jo `AndroidManifest.xml` pehle se reference kar raha tha par jo kahin define nahi thi (**iske bina build fail hota**)
- `res/drawable/launch_background.xml` (+ `drawable-v21`) — dark splash background (app ke `scaffoldBackgroundColor` 0xFF07020D se match), koi UI/design badlaav nahi
- `res/mipmap-*/ic_launcher.png` — launcher icon, jo main.dart ke in-app gradient circle + flash-icon jaisa hi hai (colors: FF6B00→FF1493→A855F7→00D2FF), kyunki `AndroidManifest.xml` `@mipmap/ic_launcher` reference karta tha jo missing thi
- `android/gradle/wrapper/gradle-wrapper.properties` — Gradle 8.3 (AGP 8.1.1 ke compatible)

**Honest gap jo maine chhupaya nahi:** `gradle-wrapper.jar` (binary file) is environment mein nahi bana sakta kyunki mujhe internet access nahi hai to download karne ke liye. FlutLab apna khud ka Gradle/Android SDK manage karta hai, to uske liye ye jar zaroori nahi hai. Agar kabhi local machine par `flutter build apk` / `./gradlew` chalao aur wrapper jar missing error aaye, to real Flutter SDK installed machine par ek baar `flutter build apk` chalao ya `gradle wrapper` command run karo — ye jar auto-generate ho jayega.

**Design ko haath nahi lagaya** — koi Dart UI file (colors, layout, widgets) is turn mein change nahi hui; sirf native Android scaffolding files add ki hain jo pehle se hi zaroori thi lekin zip mein missing thi.

## LITE BUILD — is version mein kya alag hai

Bina real FlutLab error log dekhe "zero-error" guarantee dena galat hota, isliye maine sabse bada known-risk factor pehle hata diya hai taaki build-success ka chance jyada ho:

- **`ffmpeg_kit_flutter_minimal` hata diya gaya hai** (`pubspec.yaml` se). Ye package ka native binary (~40-80MB) hi sabse zyada likely wajah thi FlutLab build fail hone ki.
- **Audio-mixing feature disabled hai, lekin honestly** — `.mp3` pick karna abhi bhi kaam karta hai, lekin video save hone par app clearly bata deta hai "audio mixing isn't available in this build" (koi fake success nahi dikhata).
- **Baaki sab kuch same hai**: real native camera, colour filters, voice-nav, chat wallpaper, Firebase, Agora, AdMob, admin badge — in mein se kuch bhi nahi chheda.

**Agar ye build bhi fail ho:** please FlutLab ke "Build" button ke baad jo actual red error text aata hai woh bhejo (Firebase/Agora console ke screenshots se pata nahi chalta) — tabhi main exact wajah fix kar sakta hoon, guess karke nahi.

**Agar ye build safal ho jaaye** aur baad mein real audio-mixing wapas chahiye ho, to `ffmpeg_kit_flutter_minimal: ^6.0.8` wapas `pubspec.yaml` mein daalo aur `audio_mix_service.dart` ka "full" version wapas use karo (dono is conversation mein pehle diye gaye hain).

## Build karne se pehle checklist
- [ ] `lib/agora_config.dart` — Agora App ID daala
- [ ] `android/app/google-services.json` — Firebase se download karke rakha
- [ ] `AndroidManifest.xml` — AdMob App ID daala
- [ ] Debug SHA-1 fingerprint Firebase mein add kiya
- [ ] `flutter pub get` run kiya
- [ ] `flutter run` ya `flutter build apk` se test kiya

## Purana WebView URL
Naye project mein purana `InAppWebView` code hata diya gaya hai (jo `ais-dev-...run.app` load kar raha tha). Ab app poori tarah aapke apne Firebase/AdMob/Agora par chalta hai — koi third-party server call nahi hai.
