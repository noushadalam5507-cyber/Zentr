/**
 * Deploy this separately with the Firebase CLI:
 *   firebase deploy --only functions
 *
 * This is NOT part of the Flutter/FlutLab build — Cloud Functions run on
 * Google's servers, not inside the app. It's what makes payments trustworthy:
 * the client only ever talks to createOrder / razorpayWebhook; it can never
 * write isPremium, premiumUntil or coinBalance itself.
 *
 * Setup:
 *   1. npm install firebase-admin firebase-functions razorpay
 *   2. Set your Razorpay KEY SECRET (never in the Flutter app!) as a
 *      Firebase secret:
 *        firebase functions:secrets:set RAZORPAY_KEY_SECRET
 *   3. In the Razorpay dashboard, add a webhook pointing to your deployed
 *      razorpayWebhook URL, subscribed to the "payment.captured" event, and
 *      set the same secret there for signature verification.
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const crypto = require("crypto");
const Razorpay = require("razorpay");

admin.initializeApp();
const db = admin.firestore();

const razorpay = new Razorpay({
  key_id: functions.config().razorpay.key_id,
  key_secret: functions.config().razorpay.key_secret,
});

// Client calls this to start a purchase (subscription or coins).
exports.createOrder = functions.https.onRequest(async (req, res) => {
  const { uid, amount, currency, purpose, coins } = req.body;

  if (!uid || !amount || !currency) {
    return res.status(400).json({ error: "Missing uid, amount, or currency" });
  }

  const order = await razorpay.orders.create({
    amount, // in paise
    currency,
    notes: { uid, purpose: purpose || "premium", coins: coins || 0 },
  });

  res.json({ orderId: order.id });
});

// Razorpay calls this automatically after a successful payment.
// This is the ONLY place that ever grants premium status or coins.
exports.razorpayWebhook = functions.https.onRequest(async (req, res) => {
  const signature = req.headers["x-razorpay-signature"];
  const expected = crypto
    .createHmac("sha256", functions.config().razorpay.webhook_secret)
    .update(JSON.stringify(req.body))
    .digest("hex");

  if (signature !== expected) {
    return res.status(400).send("Invalid signature");
  }

  const payload = req.body.payload.payment.entity;
  const notes = payload.notes || {};
  const uid = notes.uid;
  if (!uid) return res.status(400).send("Missing uid in order notes");

  const userRef = db.collection("users").doc(uid);

  if (notes.purpose === "coins") {
    await userRef.set(
      { coinBalance: admin.firestore.FieldValue.increment(Number(notes.coins) || 0) },
      { merge: true }
    );
  } else {
    // Default: premium subscription, +30 days from now.
    const premiumUntil = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    );
    await userRef.set({ isPremium: true, premiumUntil }, { merge: true });
  }

  res.status(200).send("OK");
});
